class Carrito:
    def __init__(self):
        self.productos = {}

    def agregar_producto(self, producto, cantidad):
        if producto.reducir_stock(cantidad):
            if producto.nombre in self.productos:
                self.productos[producto.nombre]['cantidad'] += cantidad
            else:
                self.productos[producto.nombre] = {'producto': producto, 'cantidad': cantidad}
            print(f"Agregado {cantidad} de {producto.nombre} al carrito.")
        else:
            print(f"No hay suficiente stock de {producto.nombre}.")

    def mostrar_carrito(self):
        if not self.productos:
            print("El carrito está vacío.")
        else:
            for item in self.productos.values():
                producto = item['producto']
                cantidad = item['cantidad']
                print(f"{producto.nombre} x {cantidad} - Subtotal: ${producto.precio * cantidad:.2f}")

    def total_compra(self, cliente):
        total = sum(item['producto'].precio * item['cantidad'] for item in self.productos.values())
        descuento = total * cliente.obtener_descuento()
        return total - descuento
