import json
from clientes.cliente import Cliente
from clientes.cliente_vip import ClienteVIP
from productos.producto import Producto
from productos.carrito import Carrito

def cargar_stock():
    try:
        with open('data/stock.json', 'r') as file:
            productos_data = json.load(file)
            return [Producto(**item) for item in productos_data]
    except FileNotFoundError:
        print("No se encontro el archivo en el stock. Asegurese de que el archivo 'stock.json' este en la carpeta 'data'.")
        return []

def guardar_stock(productos):
    productos_data = [{"nombre": p.nombre, "precio": p.precio, "stock": p.stock} for p in productos]
    with open('data/stock.json', 'w') as file:
        json.dump(productos_data, file, indent=4)

def agregar_stock(productos):
    print("\n--- Modificar Stock ---")
    for idx, producto in enumerate(productos, start=1):
        print(f"{idx}. {producto}")
    print(f"{len(productos) + 1}. Agregar un nuevo producto")

    opcion = int(input("Seleccione una opcion: "))
    
    if 1 <= opcion <= len(productos):
        producto_seleccionado = productos[opcion - 1]
        print(f"Modificando el producto: {producto_seleccionado.nombre}")
        
        nuevo_nombre = input(f"Nuevo nombre (dejar vacio para mantener '{producto_seleccionado.nombre}'): ")
        if nuevo_nombre:
            producto_seleccionado.nombre = nuevo_nombre
        
        nuevo_precio = input(f"Nuevo precio (dejar vacio para mantener '{producto_seleccionado.precio}'): ")
        if nuevo_precio:
            producto_seleccionado.precio = float(nuevo_precio)
        
        nuevo_stock = input(f"Aumentar stock en (actualmente {producto_seleccionado.stock}): ")
        if nuevo_stock:
            producto_seleccionado.stock += int(nuevo_stock)
        
        print(f"Producto {producto_seleccionado.nombre} modificado correctamente.")
    
    elif opcion == len(productos) + 1:
        nombre = input("Ingrese el nombre del nuevo producto: ")
        precio = float(input("Ingrese el precio del producto: "))
        stock = int(input("Ingrese el stock inicial del producto: "))
        nuevo_producto = Producto(nombre, precio, stock)
        productos.append(nuevo_producto)
        print(f"Producto {nombre} agregado correctamente.")
    
    else:
        print("Opcion no valida.")
    
    guardar_stock(productos)

def revisar_cliente():
    clientes = cargar_clientes()
    nombre_buscar = input("Ingrese el nombre del cliente que desea buscar: ").strip().lower()
    
    cliente_encontrado = None
    for cliente in clientes:
        if cliente.nombre.lower() == nombre_buscar:
            cliente_encontrado = cliente
            break
    
    if cliente_encontrado:
        print(f"\nDatos del cliente:")
        print(f"Nombre: {cliente_encontrado.nombre}")
        print(f"Apellido: {cliente_encontrado.apellido}")
        print(f"Direccion: {cliente_encontrado.direccion}")
        print(f"VIP: {'Si' if cliente_encontrado.es_vip else 'No'}")
    else:
        print("Cliente no existente.")

def menu():
    print("¡Bienvenidos a mi negocio online!")
    
    productos = cargar_stock()
    cliente = registrar_cliente()

    carrito = Carrito()

    while True:
        print("\n1. Ver productos\n2. Agregar al carrito\n3. Ver carrito\n4. Finalizar compra\n5. Agregar/Modificar Stock\n6. Revisar Cliente\n7. Salir")
        opcion = input("Seleccione una opcion: ")

        if opcion == "1":
            for idx, producto in enumerate(productos, start=1):
                print(f"{idx}. {producto}")
        elif opcion == "2":
            for idx, producto in enumerate(productos, start=1):
                print(f"{idx}. {producto}")
            seleccion = int(input("Ingrese el numero del producto: "))
            if 1 <= seleccion <= len(productos):
                cantidad = int(input("Ingrese la cantidad: "))
                producto = productos[seleccion - 1]
                carrito.agregar_producto(producto, cantidad)
            else:
                print("Seleccion no valida.")
        elif opcion == "3":
            carrito.mostrar_carrito()
        elif opcion == "4":
            total = carrito.total_compra(cliente)
            print(f"Total a pagar: ${total}")
            print("Compra finalizada. Gracias por su compra")
            break
        elif opcion == "5":
            agregar_stock(productos)
        elif opcion == "6":
            revisar_cliente()
        elif opcion == "7":
            print("Saliendo..")
            break
        else:
            print("Opcion no valida. Intente de nuevo.")

def registrar_cliente():
    nombre = input("Ingrese su nombre: ")
    apellido = input("Ingrese su apellido: ")
    direccion = input("Ingrese su direccion: ")
    es_vip = input("¿Es usted un cliente VIP? (s/n): ").lower() == 's'
    
    if es_vip:
        cliente = ClienteVIP(nombre, apellido, direccion)
    else:
        cliente = Cliente(nombre, apellido, direccion)
    
    clientes = cargar_clientes()
    clientes.append(cliente)
    guardar_clientes(clientes)
    print(f"Cliente {cliente} registrado con exito.")
    
    return cliente

def cargar_clientes():
    try:
        with open('data/clientes.json', 'r') as file:
            clientes_data = json.load(file)
            clientes = []
            for cliente_data in clientes_data:
                if cliente_data['es_vip']:
                    clientes.append(ClienteVIP(cliente_data['nombre'], cliente_data['apellido'], cliente_data['direccion']))
                else:
                    clientes.append(Cliente(cliente_data['nombre'], cliente_data['apellido'], cliente_data['direccion']))
            return clientes
    except FileNotFoundError:
        return []

def guardar_clientes(clientes):
    clientes_data = [
        {"nombre": c.nombre, "apellido": c.apellido, "direccion": c.direccion, "es_vip": c.es_vip} 
        for c in clientes
    ]
    with open('data/clientes.json', 'w') as file:
        json.dump(clientes_data, file, indent=4)

if __name__ == "__main__":
    menu()
