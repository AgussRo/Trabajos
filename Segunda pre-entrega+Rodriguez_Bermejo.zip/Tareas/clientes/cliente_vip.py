from clientes.cliente import Cliente

class ClienteVIP(Cliente):
    def __init__(self, nombre, apellido, direccion):
        super().__init__(nombre, apellido, direccion, es_vip=True)
