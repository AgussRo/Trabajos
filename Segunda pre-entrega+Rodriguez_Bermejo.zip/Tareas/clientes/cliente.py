class Cliente:
    def __init__(self, nombre, apellido, direccion, es_vip=False):
        self.nombre = nombre
        self.apellido = apellido
        self.direccion = direccion
        self.es_vip = es_vip

    def __str__(self):
        tipo_cliente = "VIP" if self.es_vip else "Regular"
        return f"{self.nombre} {self.apellido} ({tipo_cliente})"
    
    def obtener_descuento(self):
        return 0.10 if self.es_vip else 0.0
